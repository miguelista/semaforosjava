package view;

import java.util.concurrent.Semaphore;

public class estacionamentocavalo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int permissoes = 3;
		Semaphore semaforo = new Semaphore(permissoes);
		
		for (idCavalo = 0; idCavalo < 10; idCavalo++) {
			Thread tCavalo = new Threadcavalo(idCavalo, semaforo);
			tCavalo.start();
		}
	}

}
s