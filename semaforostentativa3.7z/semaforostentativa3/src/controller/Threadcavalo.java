package controller;

import java.util.concurrent.Semaphore;

public class Threadcavalo extends Thread {

	private int idCavalo;
	private static int posChegada;
	private static int posSaida;
	private Semaphore semaforo;

	public Threadcavalo() {
		this.idCavalo = idCavalo;
		this.semaforo = semaforo;

	}

	@Override
	public void run() {
		cavaloAndando();
		// se��o cr�tica//
		try {
			semaforo.acquire();
			cavaloEstacionado();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			semaforo.release();
			// fim d.se��o cr�tica//
			cavaloSaindo();
		}
	}

	private void cavaloAndando() {
		// TODO Auto-generated method stub
		int distanciaTotal = (int) ((Math.random() * 2001) + 0);
		int distanciaPercorrida = 0;
		int deslocamento = (int) ((Math.random() * 2) + 2);
		int tempo = 1000;
		while (distanciaPercorrida < distanciaTotal) {
			distanciaPercorrida += deslocamento;
			try {
				sleep(tempo);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println("#" + idCavalo + " j� andou " + distanciaPercorrida + "m.");
		}
		posChegada++;
		System.out.println("#" + idCavalo + " foi o " + posChegada + " o. a chegar!");

	}

	private void cavaloEstacionado() {
		// TODO Auto-generated method stub
		System.out.println("#" + idCavalo + " chegou");
		int tempo = (int) ((Math.random() * 2001) + 1000);
		try {
			sleep(tempo);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	private void cavaloSaindo() {
		// TODO Auto-generated method stub
		posSaida++;
		System.out.println("#" + idCavalo + " foi o " + posSaida + "o. a sair");
	}

}
